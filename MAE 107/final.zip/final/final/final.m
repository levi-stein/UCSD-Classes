clear all; close all; clc; format long; format compact;

%% Student name, ID number, and homework_number are required
name = 'Levi Stein';
id = 'A16791467';
hw_num = 'final';

%% Set up physical parameters

global d1 d2 l r kappa g nu rho time_rain precipitation

% Load precipitation which has time_rain and precipitation
load('rain_data.mat'); 

% Drainage system parameters:
d1 = 2;                % tank diameter in meter
d2 = 0.05;             % pipe diameter in meter
l = 0.5;               % pipe length in meter
r = 0.0001;            % pipe roughness ratio (unitless)
kappa = 1.5;           % head loss due to pipe entrance and exit (unitless)

% Water property:
g = 9.81;              % gravity in meter per squared second
nu = 1e-6;             % kinematic vicosity of water in squared meter per second)
rho = 1000;            % density of water in kg per cubic meter
%% Interpolate Percipitation using Cubic Splines to reduce h
% newstep = [0:0.3:900];
% S = zeros(1,3000);
% S(end) = precipitation(end);
% S(1) = precipitation(1);
% for i = 2:length(newstep)-1
% S(i) = clamped_cubic_spline(time_rain,precipitation,0,0,newstep(i));
% end
%% Solve IVP:
w0 = 0.5;           % initial water depth in the tank
u0 = 1.9;           % initial velocity at pipe exit
h = 0.3;            % time step in second
tspan = [0 900];        % time span in second

[t, y] = ivpsys_RKM([w0 u0], h, tspan);
w = y(:,1);          % extract depth from matrix y
u = y(:,2);          % extract velocity from matrix y


%% Analyis 1: Plotting  depth w and velocity u and dw/dt
% dwdt = zeros(1,length(t));
% dwdt(1) = -1*((d2^2)/(d1^2))*u0 + precipitation(1);
% dwdt(end) = -1*((d2^2)/(d1^2))*u(end) + precipitation(end);
% for i = 2:length(t)-1
%     dwdt(i) = (w(i+1) - w(i-1))/(2*h);
% end

figure(1);

% Top panel: depth vs time
subplot(3,1,1);
plot(t,w,'k');
xlabel('time t (s)');
ylabel('depth w (m)');
title('water depth vs time')
box on; grid on; set(gca,'FontSize',12);

% Middle panel: velocity vs time
subplot(3,1,2);
plot(t,u,'k');
xlabel('time t (s)');
ylabel('velocity u (m/s)');
title('exit velocity vs time')
box on; grid on; set(gca,'FontSize',12);

% Bottom panel: time rate of change in depth vs time
% subplot(3,1,3);
% plot(t,dwdt,'k','LineWidth',1);
% xlabel('time t (s)');
% ylabel('dw/dt (m/s)');
% title('time rate of change in depth vs time')
% box on; grid on; set(gca,'FontSize',12);

% p1a = 'See figure 1';
% p1b = dwdt(1);
% p1c = dwdt(2);
% p1d = dwdt(end);

%% Analysis 2: Solve Colebrook eqn for friction factor 
Re = u*d2/nu;
for n = 1:length(Re)
    friction_factor(n) = colebrook(r,Re(n));
end

figure(2);
plot(Re,friction_factor,'-*');
xlabel('Reynolds number Re'); ylabel('friction factor f'); 
title('Frictional factor for turbulent flows in pipe from Colebrook equation');
box on; grid on; set(gca,'FontSize',12);

% p2a = 'See figure 2';

%% Analysis 3: power model fit to predict velocity for given depth range

[alpha, beta, fun] = best_fit_power_model(w,u);

figure(3); hold on;
plot(w,u,'k*');
depth_range = 0.05:0.05:1;
plot(depth_range,fun(depth_range),'-r');
xlabel('water depth (m)'); 
ylabel('velocity (m/s)');
legend('simulation result','power model result');
title('Power model fit for velocity as a function of water depth');
box on; grid on; set(gca,'FontSize',12);

% p3a = 'See figure 3';
% p3b = alpha;
% p3c = beta;

%%  Analysis 4: Mass conservation
% Get the rain rate that goes into the simulation
% for n = 1:length(t)
%     S(n) = ...
% end

% m_change = ...
% m_rain = ...
% m_out = ...
% 
% p4a = m_change;
% p4b = m_rain;
% p4c = m_out;
% p4d = m_change - m_rain - m_out;