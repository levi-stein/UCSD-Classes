function yp = ivpsys_fun(t, y)
% IVPSYS_FUN evaluates the right-hand-side of the ODE's.
% Inputs are current time and current values of y's. 
% y's include the water depth w in y(1) and exit velocity u in y(2).
% Outputs are values of yprime's.
% Call format: yp = ivpsys_fun(t, y)

global d1 d2 l r kappa g nu time_rain precipitation


%% Get friction factor
% ...
% ...

%% Get precipitation
% ...


%% Obtain yp
% ...
% ...

end % function ivpsys_fun